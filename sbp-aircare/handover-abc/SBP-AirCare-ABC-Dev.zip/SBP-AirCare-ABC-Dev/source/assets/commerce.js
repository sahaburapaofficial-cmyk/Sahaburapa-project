// SBP AirCare — commerce layer shared by all three prototypes:
// product detail with install package + add-ons, full service price centre, quote basket, zone/travel fee.
// Markup uses the "s-" classes styled in assets/shared.css through each variant's alias tokens.
import { SMALL_VISIT } from './rates.js';   // ★Rev.27
import { mountMatCards } from './matcards.js';
import {
  DATA, DEMO, cleanRate, TYPES, TYPE_BY_ID, BRAND_BY_ID, CLEAN_PKGS, VAT, incVat, timeTh, TIME_NOTE, baht, btuFmt, installOptions, addonsFor,
  checkZone, TIER_TH, TRAVEL, h, $, $$, stockTh, jobTravel, travelNote, zoneOf, addrTh, SIZE_BANDS, isVRF, VRF_NOTE, COMPANY,
} from './sbp-core.js';
import { typeArt, toast } from './proto-ui.js';
import { askTeam, copyText, lineLink, handoffBox } from './contact.js';
import { deliver, canSend, privacyNote, honeypot, newRid, withRef } from './submit.js';
import { productVisual } from './product-media.js';
import { judge, bkkNow, dateTh, addDays, isOpen, LEAD_DAYS, RUSH_FEE_EX, SLOTS, fetchSlots, slotFree } from './queue.js';
import { ticketPanel, ticketText, sendTicket, photoLine, jobsIn } from './ticket.js';
import { canReach, ENDPOINT, BACKEND } from './submit.js';
import { watchPanel } from './backpanel.js';
import { breakdown, packageParts, pipeBundle, optionNote, pipeItemFor } from './costs.js';
import { addrPicker } from './addrpick.js';

// Rev.16: what the crew will do on the visit, for the queue rules (visit time → slots)
// ★Rev.21.1 (review BUG-05): every cleaning line says its type and level — quick booking (QC-), price centre (C-) and the
// service / crew sections (CL-) alike; a line whose time is not published (AHU, coil-only, duct …) is on the visit with
// "unknown" time (the team confirms), never quietly a wall unit C1; add-ons (heavy dirt, height) are not extra units
const CLEAN_KEY = /^(?:QC|CL|C)-.+-(C1|C2)-(wall|ceiling|cassette|floor|duct)-/;
export function visitLines(items) {
  const J = jobsIn(items), out = [];
  items.forEach(i => {
    if (i.group !== 'clean' || i.unitEx == null) return;
    const m = CLEAN_KEY.exec(i.key || '');
    if (m) { out.push({ t: m[2], level: m[1], qty: i.qty }); return; }
    const r = /^CX-/.test(i.key || '') ? DATA.clean.find(r => r.name === i.key.slice(3)) : null;
    if (r && /^(งานเพิ่ม|Access)/.test(r.ty || '')) return;
    out.push({ t: null, level: 'C1', qty: i.qty, unknown: true });
  });
  (J.units || []).forEach(u => out.push({ t: u.type, level: 'install', qty: u.qty }));   // each installation line with its own type
  if (J.surveys) out.push({ t: null, level: 'install', qty: J.surveys, unknown: true });
  if (J.repair) out.push({ t: 'wall', level: 'repair', qty: J.repair });   // no published time for repair — half-day slot, no time estimate
  return out;
}
const RUSH = () => ({ kind: 'service', group: 'rush', src: 'qc', fixed: true, key: 'QC-RUSH', name: 'คิวด่วน (ภายใน 3 วัน)', detail: 'ต่อการเข้างาน · รับเมื่อมีทีมว่าง ถ้าไม่มีคิวไม่เก็บค่านี้', unitEx: RUSH_FEE_EX, qty: 1 });
// keep exactly one rush line when the chosen date is inside the rush window and the quotation has a visit (clean / install)
export function syncRush(date) {
  const need = !!date && judge(date, [], 'C1').rush && visitLines(cart.items).length > 0, has = cart.items.some(i => i.group === 'rush');
  if (need && !has) cart.items.push({ id: Math.random().toString(36).slice(2, 9), ...RUSH() });
  if (!need && has) cart.items = cart.items.filter(i => i.group !== 'rush');
  if (need !== has) cart.save();
}

// ★Rev.33 which design the request came from (site.js marks the page; D/E/F and single-file builds used to send none)
const pageVariant = () => document.documentElement.dataset.sxVariant || ((location.pathname.match(/([a-f])\.html/) || [])[1] || '').toUpperCase();

// Rev.16.1: after a job ticket is sent — keep the reference, a tentative calendar entry, chat with the team
function afterTools(s) {
  const d = cart.prefDate, slot = cart.prefSlot || '';
  const ics = () => { const day = d.replace(/-/g, ''), st = /บ่าย/.test(slot) ? '130000' : '083000', en = /เช้า/.test(slot) ? '120000' : '173000';
    const txt = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//SBP AirCare//Booking//TH', 'BEGIN:VEVENT', `UID:${s.ref}@sbp-aircare`, `DTSTAMP:${new Date().toISOString().replace(/[-:]/g, '').slice(0, 15)}Z`,
      `DTSTART;TZID=Asia/Bangkok:${day}T${st}`, `DTEND;TZID=Asia/Bangkok:${day}T${en}`, `SUMMARY:SBP AirCare (รอยืนยันคิว) ${s.ref}`, `DESCRIPTION:เลขอ้างอิง ${s.ref} · ทีมยืนยันคิวและเวลาก่อนวันนัด · โทร ${COMPANY.tel}`, 'STATUS:TENTATIVE', 'END:VEVENT', 'END:VCALENDAR'].join('\r\n');
    const a = h('a', { href: URL.createObjectURL(new Blob([txt], { type: 'text/calendar' })), download: `SBP-${s.ref}.ics` }); document.body.append(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1500); };
  return h('div', { class: 's-after' },
    h('button', { type: 'button', class: 's-btn ghost', onclick: async () => toast((await copyText(s.ref)) ? `คัดลอกเลขอ้างอิง ${s.ref} แล้ว` : `เลขอ้างอิง ${s.ref}`) }, `คัดลอกเลขอ้างอิง ${s.ref}`),
    d ? h('button', { type: 'button', class: 's-btn ghost', onclick: ics }, 'บันทึกลงปฏิทิน (รอยืนยัน)') : null,
    h('a', { class: 's-btn ghost', href: lineLink(`เลขอ้างอิง ${s.ref} · สอบถามใบจองงาน`), target: '_blank', rel: 'noopener' }, 'แชทกับทีมทาง LINE'));
}

let liveQ = null, liveAsked = false;   // Rev.19 live queue, fetched once per page when a visit is in the cart
// Rev.15: one line under the quotation date field — what the chosen date means under the queue rules (queue.js)
function dateHint(date, hasRush) {
  const J = judge(date, [], 'C1'), fee = baht(RUSH_FEE_EX);
  const txt = !date ? `จองปกติล่วงหน้า ${LEAD_DAYS} วัน (เร็วสุด ${dateTh(J.earliest)}) · เร็วกว่านั้นเป็นคิวด่วน +${fee} ก่อน VAT ต้องมีคิวว่าง`
    : J.kind === 'past' ? 'วันที่ผ่านมาแล้ว เลือกวันนี้หรือวันถัดไป'
    : J.rush ? (hasRush ? `คิวด่วน +${fee} อยู่ในรายการแล้ว · ทีมยืนยันคิวก่อน ถ้าไม่มีคิวไม่เก็บค่านี้` : `วันนี้อยู่ในช่วงคิวด่วน (+${fee} ก่อน VAT ต่อการเข้างาน ถ้ามีคิวว่าง) ทีมยืนยันกับคุณก่อน`)
    : 'จองปกติ · ทีมยืนยันคิวและเวลาเข้างาน';
  return h('p', { class: 's-note' + (J.rush || J.kind === 'past' ? ' warn' : ''), style: 'margin-top:-6px' }, txt + (J.closed ? ' · วันอาทิตย์เป็นงานนอกเวลา มีค่าใช้จ่ายเพิ่มเติม' : ''));
}

const exInc = ex => (ex == null ? null : { ex, inc: incVat(ex) });
const priceNode = (ex, unit) => ex == null
  ? h('span', { class: 's-price survey' }, 'ประเมินหน้างาน')
  : h('span', { class: 's-price' }, h('b', {}, baht(ex)), h('small', {}, `ก่อน VAT${unit ? ' / ' + unit : ''}`));

/* =========================================================
   Quote basket
   ========================================================= */
// Rev.18: saved quotations keep the price they were added at — re-price every line we can identify from its key against the
// current Pricebook (rounding / new rates) whenever a saved cart loads; lines that cannot be identified keep their price
export const PRICE_V = 19;   // ★Rev.27: lines priced by rates.js (removal, relocation, refrigerant per kg …)
export function repriceLine(l) {
  const k = l.key || '', m = (re) => re.exec(k);
  let x;
  if ((x = m(/^P-(.+)$/))) { for (const md of DEMO.models) { const s = md.skus.find(s => s.sku === x[1]); if (s) return { ...l, unitEx: s.px }; } return l; }
  if ((x = m(/^(?:I|IN)-([A-Z0-9.-]+)$/)) && DATA.instByCode[x[1]]) return { ...l, unitEx: DATA.instByCode[x[1]].ex };
  // ★Rev.27 add-on / survey lines whose item now has a standard rate become priced add-ons
  if ((x = m(/^(A|S)-(.+?)(-FIT)?$/)) && DATA.instByCode[x[2]] && DATA.instByCode[x[2]].ex != null) return { ...l, kind: l.kind === 'survey' ? 'addon' : l.kind, key: x[1] === 'S' ? `A-${x[2]}` : l.key, unitEx: DATA.instByCode[x[2]].ex };
  if ((x = m(/^(?:QC|CL)-(.+)-(C1|C2)-(wall|ceiling|cassette|floor)-(\d+)$/))) { const r = cleanRate(x[1], x[2], x[3], +x[4]); return r && r.rate.s != null ? { ...l, unitEx: r.rate.s } : l; }
  if ((x = m(/^C-(.+)-(C1|C2)-(\w+)-(.+)$/))) { const r = DATA.clean.find(r => r.pkg === x[1] && r.level === x[2] && r.type === x[3] && r.range === x[4]); return r && r.rate.s != null ? { ...l, unitEx: r.rate.s } : l; }
  if ((x = m(/^CX-(.+)$/))) { const r = DATA.clean.find(r => r.name === x[1]); return r && r.rate.s != null ? { ...l, unitEx: r.rate.s } : l; }
  if ((x = m(/^(?:R|RP)-(.+)$/))) { const r = DATA.rep.find(r => r.name === x[1]); return r && r.rate.s != null ? { ...l, unitEx: r.rate.s } : l; }
  return l;
}
const KEY = 'sbp-quote-v2', DKEY = 'sbp-booking-v1';
// Rev.26: trade-in record (tradein.tradeInSummary) — only while a trade-in request line is in the quote
const tiOf = D => (cart.items.some(i => /^TI-/.test(i.key || '')) && D.tradein && D.tradein.text) || '';   // Rev.16.1: booking draft (answers / contact / date) — never photos
// Rev.11: the quotation maths as pure functions — the cart and the quick cleaning booking (quickclean.js) share them,
// so every total on the site follows the same rules (VAT, cleaning minimum per visit, travel by zone and unit count).
// machines on site = the largest per-group count (a product + its install line is still one machine)
export function quoteUnits(items) {
  const by = {}; items.forEach(i => { if (['product', 'install', 'clean', 'repair'].includes(i.group)) by[i.group] = (by[i.group] || 0) + (i.units || i.qty); });
  return Math.max(0, ...Object.values(by));
}
export function quoteTotals(items, zone) {
  let ex = 0, cleanEx = 0;
  items.forEach(i => { if (i.unitEx != null) { ex += i.unitEx * i.qty; if (i.group === 'clean') cleanEx += i.unitEx * i.qty; } });
  const units = quoteUnits(items);
  // annual contracts already carry travel per visit — only charge a trip for the one-off lines
  const oneOff = items.some(i => i.group !== 'contract' && i.kind !== 'survey');
  // ★Rev.20 travel: core area free when the cleaning reaches the minimum, otherwise one trip fee; distance fee outside the core area
  const tr = oneOff ? jobTravel(zone, cleanEx) : { fee: 0, small: false, label: '' };
  const travel = tr.fee, minGap = 0;
  // ★Rev.27 small work only (no cleaning / installation / repair / contract line in this visit): the items count toward the
  // per-visit minimum (rates.SMALL_VISIT) and the difference is the visit charge
  const main = items.some(i => ['clean', 'install', 'repair', 'contract'].includes(i.group));
  const smallEx = items.filter(i => i.group === 'addon' && i.unitEx != null).reduce((n, i) => n + i.unitEx * i.qty, 0);
  const small = !main && items.some(i => i.group === 'addon');
  const visit = small ? Math.max(0, SMALL_VISIT.minEx - smallEx) : 0;
  const totalEx = ex + travel + visit;
  return { ex, travel, travelLabel: tr.label, travelSmall: tr.small, travelWaived: false, travelShort: 0, units, minGap, cleanEx, visit, visitSmall: small, visitLabel: `${SMALL_VISIT.th} ${baht(SMALL_VISIT.minEx)}`, totalEx, vat: Math.round(totalEx * VAT), inc: totalEx + Math.round(totalEx * VAT), surveys: items.filter(i => i.unitEx == null).length };
}
export const cart = {
  items: [], zone: null, zoneInput: '', addr: null, subs: new Set(),   // Rev.20 addr = picked {p, d, s, z}
  draft: { name: '', tel: '', line: '', tax: '', ans: {}, photos: [], note: '', scope: [], addr: '', map: '', when: '' },   // Rev.16 booking form + ticket (memory only — photos never stored)
  prefSlot: '',   // Rev.15: slot chosen in the quick booking (ช่วงเช้า / ช่วงบ่าย / ทั้งวัน)
  prefDate: '',   // Rev.11: preferred date carried in from the quick booking (kept in memory; the form shows it whenever it renders)
  load() { try { const j = JSON.parse(localStorage.getItem(KEY) || 'null'); if (j) { this.items = (j.items || []).map(l => (j.pv || 0) < PRICE_V ? repriceLine(l) : l); this.zoneInput = j.zoneInput || ''; this.addr = j.addr || null; this.zone = this.addr ? zoneOf(this.addr) : this.zoneInput ? checkZone(this.zoneInput) : null; } } catch (e) {}
    try { const d = JSON.parse(localStorage.getItem(DKEY) || 'null'); if (d) { Object.assign(this.draft, d.draft || {}, { photos: [] }); if (d.date && d.date >= bkkNow().date) { this.prefDate = d.date; this.prefSlot = d.slot || ''; } } } catch (e) {} },
  saveDraft() { try { const { photos, scope, units, ...rest } = this.draft; localStorage.setItem(DKEY, JSON.stringify({ draft: rest, date: this.prefDate, slot: this.prefSlot })); } catch (e) {} },
  clearDraft() { this.draft = { name: this.draft.name, tel: this.draft.tel, line: this.draft.line, tax: this.draft.tax, ans: {}, photos: [], note: '', scope: [], addr: '', map: '', when: this.draft.when }; this.prefDate = ''; this.prefSlot = ''; this.saveDraft(); },
  save() { try { localStorage.setItem(KEY, JSON.stringify({ pv: PRICE_V, items: this.items, zoneInput: this.zoneInput, addr: this.addr })); } catch (e) {} this.subs.forEach(f => f(this)); },
  add(line) {
    const same = this.items.find(i => i.key && i.key === line.key);
    if (same && line.kind !== 'survey') same.qty += line.qty || 1; else if (!same) this.items.push({ id: Math.random().toString(36).slice(2, 9), qty: 1, ...line });
    this.save();
  },
  setQty(id, q) { const it = this.items.find(i => i.id === id); if (!it) return; it.qty = Math.max(1, Math.min(999, q)); this.save(); },
  remove(id) { this.items = this.items.filter(i => i.id !== id); this.save(); },
  clear() { this.items = []; this.save(); },
  setZone(input) { if (input && typeof input === 'object') { this.addr = input; this.zoneInput = addrTh(input); this.zone = zoneOf(input); } else { this.addr = null; this.zoneInput = input || ''; this.zone = checkZone(input); } this.save(); },
  setAddr(a, text) { this.addr = a || null; this.zoneInput = a ? addrTh(a) : (text || ''); this.zone = a ? zoneOf(a) : (text ? checkZone(text) : null); this.save(); },
  count() { return this.items.reduce((n, i) => n + (i.kind === 'survey' ? 0 : i.qty), 0); },
  totals() { return quoteTotals(this.items, this.zone); },
  units() { return quoteUnits(this.items); },
};

export function mountCart({ buttons = '[data-cart-btn]' } = {}) {
  cart.load();
  const dr = h('div', { class: 's-cart', hidden: true, role: 'dialog', 'aria-modal': 'true', 'aria-label': 'ใบเสนอราคาเบื้องต้น' });
  const panel = h('div', { class: 's-cart-panel' });
  dr.append(panel); document.body.append(dr);
  const close = () => { dr.classList.remove('open'); document.body.classList.remove('lock'); setTimeout(() => dr.hidden = true, 250); };
  const open = () => { liveAsked = false; render(); dr.hidden = false; requestAnimationFrame(() => dr.classList.add('open')); document.body.classList.add('lock'); };
  dr.addEventListener('click', e => { if (e.target === dr) close(); });
  addEventListener('keydown', e => { if (e.key === 'Escape' && !dr.hidden) close(); });
  watchPanel(dr, () => !dr.hidden && dr.classList.contains('open'), close);   // ★Rev.34 Back closes the quotation instead of switching the page behind it
  let sent = null;
  // ★Rev.33 (workflow check): once a request has gone, adding anything else from the site starts the next one — the panel used to keep
  // showing the old confirmation and hid what was just added. Lines that reached the team leave the list (never sent twice) and the
  // sent ticket's answers / photos / note / date stay with it (name and phone are kept, as "เริ่มใบใหม่" does); when it did not reach
  // the team nothing is dropped — it goes with the new lines. A note names the earlier request. Waits while a send is in flight.
  let prev = null;
  const grewSince = s => cart.items.some(i => !s.snap.has(i.id) || i.qty > s.snap.get(i.id));
  function moveOn() {
    if (!sent || !sent.snap || sent.state === 'pending' || !grewSince(sent)) return false;
    const s = sent; sent = null; prev = s;
    if (s.state === 'ok') { cart.items = cart.items.flatMap(i => !s.snap.has(i.id) ? [i] : i.qty > s.snap.get(i.id) ? [{ ...i, qty: i.qty - s.snap.get(i.id) }] : []); cart.clearDraft(); cart.save(); }
    return true;
  }
  // a request handed to the team (sent — or the summary box, when this page cannot send) completes the visitor's journey (site.js)
  const handed = s => { try { document.dispatchEvent(new CustomEvent('sbp:sent', { detail: { ref: s.ref, job: s.isJob, ok: s.state === 'ok' } })); } catch (e) { /* journey strip only */ } };
  const settle = s => { if (sent === s && moveOn() && !dr.hidden) render(); };
  const prevNote = s => h('p', { class: 's-note s-prev' }, `${s.isJob ? 'ใบจองงาน' : 'คำขอใบเสนอราคา'} เลขอ้างอิง ${s.ref} ${s.state === 'ok' ? 'ส่งถึงทีมแล้ว · รายการด้านล่างเป็นคำขอใหม่' : 'ยังไม่ได้ส่งถึงทีมจากหน้านี้ · รายการเดิมยังอยู่ในใบนี้ ส่งรวมกับรายการใหม่ได้'}`);
  const quoteText = () => { const t = cart.totals(); return ['ใบเสนอราคาเบื้องต้น SBP AirCare', ...cart.items.map(i => `• ${i.name}${i.detail ? ' (' + i.detail + ')' : ''} × ${i.qty}${i.unitEx == null ? ' — ประเมินหน้างาน' : ' — ' + baht(i.unitEx * i.qty)}`), `พื้นที่: ${cart.zoneInput || '-'}${cart.zone && cart.zone.km != null ? ` (ระยะถนนประมาณ ${cart.zone.km} กม.)` : ''}`, t.travel ? `${t.travelLabel}: ${baht(t.travel)}` : null, t.visit ? `${t.visitLabel}: ${baht(t.visit)}` : null, `รวมทั้งสิ้น ${baht(t.inc)} (รวม VAT)`].filter(x => x != null).join('\n'); };
  function render() {
    if (!sent) syncRush(cart.prefDate);   // Rev.16.1: the rush line follows the date and disappears with the last visit line
    const t = cart.totals();
    panel.innerHTML = '';
    panel.append(h('div', { class: 's-cart-h' }, h('div', {}, h('b', {}, (() => { const j = jobsIn(cart.items); return j.clean || j.install || j.repair ? 'ใบจองงาน · ใบเสนอราคาเบื้องต้น' : 'ใบเสนอราคาเบื้องต้น'; })()), h('small', {}, `${cart.items.length} รายการ`)), h('button', { type: 'button', class: 's-x', 'aria-label': 'ปิด', onclick: close }, '×')));
    const body = h('div', { class: 's-cart-b' }); panel.append(body);
    if (sent) {
      // Rev.10: send to the team once (submit.js); without an endpoint (or inside an artifact) this is the honest hand-off box
      if (!sent.box) { sent.box = h('div'); const variant = pageVariant();
        // ★Rev.21.1 (review BUG-03): the reference the team's sheet gives back replaces ours everywhere — summary, copy, LINE, calendar
        const finalRef = (s, r) => { if (!r || r === s.ref) return; s.text = withRef(s.text, s.ref, r); s.ref = r; if (sent === s) render(); };
        const viaMail = () => { const s1 = sent; s1.state = 'pending'; return deliver(s1.box, s1.isJob ? 'booking' : 'quote', { ref: s1.ref, variant: pageVariant(), fields: s1.fields, hp: s1.hp, text: s1.text, title: s1.isJob ? 'ใบจองงานของคุณ' : 'ใบเสนอราคาเบื้องต้นของคุณ', subject: s1.isJob ? 'ใบจองงาน SBP AirCare' : 'ขอใบเสนอราคา SBP AirCare', onRef: r => finalRef(s1, r) }).then(ok => { s1.state = ok ? 'ok' : 'fail'; if (ok || !canSend()) handed(s1); if (sent === s1 && s1.isJob) s1.box.append(photoLine(s1.ref, s1.photos.length)); settle(s1); }); };
        // Rev.16: the job ticket goes to the back office with its photos when it is connected; otherwise (or if it fails) the e-mail path
        if (sent.isJob && canReach()) {
          const s0 = sent;
          // ★Rev.21.1: "ลองส่งอีกครั้ง" sends the SAME request id — if the first try did reach the sheet (time-out after saving),
          // the back office answers with that ticket instead of making a second one (review AT-12)
          const go = () => {
            s0.state = 'pending'; s0.box.innerHTML = '';
            s0.box.append(h('div', { class: 's-hand', role: 'status' }, h('p', {}, `กำลังส่งใบจองงาน${s0.photos.length ? ` พร้อมรูป ${s0.photos.length} รูป` : ''} · เลขอ้างอิง ${s0.ref}`)));
            sendTicket({ ref: s0.ref, rid: s0.rid, variant, page: location.pathname + location.hash, fields: s0.fields, text: s0.text, hp: s0.hp, photos: s0.photos, scope: (cart.draft.scope || []).map(x => ({ job: x.k, lines: x.r.lines, est: x.r.est })), answers: cart.draft.ans })
              .then(r => { s0.state = r.ok ? 'ok' : 'fail'; if (r.ok) handed(s0); if (sent !== s0) return; s0.box.innerHTML = '';
                if (!r.ok) {   // Rev.19: when every form already goes to the back office, never post the same ticket there under a new id — hand it over or retry
                  if (ENDPOINT !== BACKEND) { viaMail(); return; }
                  s0.box.append(handoffBox({ ref: s0.ref, title: 'ใบจองงานของคุณ', text: s0.text, subject: 'ใบจองงาน SBP AirCare', note: 'ส่งอัตโนมัติไม่สำเร็จ (การเชื่อมต่อขัดข้อง) — ยังไม่ได้รับการยืนยันจากระบบ กดลองส่งอีกครั้ง (ไม่เกิดใบจองซ้ำ) หรือส่งสรุปนี้ทาง LINE / อีเมล / โทรแจ้งเลขอ้างอิง' }),
                    h('button', { type: 'button', class: 's-btn primary s-retry', onclick: go }, 'ลองส่งอีกครั้ง'), photoLine(s0.ref, s0.photos.length)); settle(s0); return; }
                if (r.ref && r.ref !== s0.ref) { s0.text = withRef(s0.text, s0.ref, r.ref); s0.ref = r.ref; }   // review BUG-03: one number everywhere
                s0.box.append(h('div', { class: 's-hand s-hand-ok', role: 'status' }, h('p', { class: 's-hand-b' }, 'ส่งถึงทีมแล้ว'), h('h3', {}, 'ใบจองงานของคุณ', h('small', {}, ` · เลขอ้างอิง ${s0.ref}`)),
                  h('p', {}, `ทีมได้รับรายละเอียด${r.photos ? `และรูป ${r.photos} รูป` : ''}แล้ว จะตรวจขอบเขตงาน แจ้งราคาส่วนเพิ่ม (ถ้ามี) และยืนยันคิวกับคุณก่อนวันนัด · ตรวจสถานะได้ด้วยเลขอ้างอิงในหน้าติดต่อเรา`),
                  h('textarea', { class: 's-hand-t', readonly: true, rows: 8, 'aria-label': 'สรุปใบจองงาน' }, s0.text)));
                if ((r.photos || 0) < s0.photos.length) s0.box.append(photoLine(s0.ref, s0.photos.length - (r.photos || 0)));   // review BUG-06: say which photos did not arrive
                moveOn(); render(); });   // the reference tools below follow the final number (or the next request, if one was started meanwhile)
          };
          go();
        } else viaMail(); }
      body.append(sent.box,
        h('div', { class: 's-hand-act' }, h('button', { type: 'button', class: 's-btn ghost', onclick: () => { sent = null; render(); } }, 'กลับไปแก้รายการ'), h('button', { type: 'button', class: 's-btn ghost', onclick: () => { sent = null; prev = null; cart.clear(); cart.clearDraft(); render(); } }, 'เริ่มใบใหม่')),
        sent.isJob ? afterTools(sent) : null);
      return;
    }
    if (!cart.items.length) prev = null; else if (prev) body.append(prevNote(prev));
    if (!cart.items.length) { body.append(h('div', { class: 's-empty' }, h('p', {}, 'ยังไม่มีรายการ'), h('p', { class: 's-note' }, 'เลือกรุ่นแอร์ในหน้าสินค้า หรือกด "เพิ่ม" ในตารางค่าบริการ'), h('button', { type: 'button', class: 's-btn', onclick: () => { close(); ($('#prices') || $('#catalog'))?.scrollIntoView({ behavior: 'smooth' }); } }, 'ไปที่ค่าบริการ'))); return; }
    const J0 = jobsIn(cart.items);
    if (J0.clean || J0.install || J0.repair) body.append(h('p', { class: 's-step' }, h('span', {}, '1'), 'รายการและราคา', h('small', {}, 'ราคาต่อรายการก่อน VAT')));
    const list = h('ul', { class: 's-lines' });
    cart.items.forEach(i => {
      list.append(h('li', { class: i.unitEx == null ? 'sv' : '' },
        h('div', { class: 's-l-t' }, h('b', {}, i.name), i.detail ? h('small', {}, i.detail) : null),
        i.unitEx == null ? h('span', { class: 's-price survey' }, 'ประเมินหน้างาน')
          : i.fixed ? h('div', { class: 's-l-q' }, h('span', { class: 's-l-p' }, baht(i.unitEx * i.qty)))   // Rev.15: one per visit (คิวด่วน) — no quantity
          : h('div', { class: 's-l-q' },
            h('div', { class: 's-stp' }, h('button', { type: 'button', 'aria-label': 'ลด', onclick: () => { cart.setQty(i.id, i.qty - 1); render(); } }, '−'), h('span', {}, String(i.qty)), h('button', { type: 'button', 'aria-label': 'เพิ่ม', onclick: () => { cart.setQty(i.id, i.qty + 1); render(); } }, '+')),
            h('span', { class: 's-l-p' }, baht(i.unitEx * i.qty))),
        i.group === 'rush' ? h('small', { class: 's-l-n' }, 'เปลี่ยนเป็นวันจองปกติเพื่อยกเลิก') : h('button', { type: 'button', class: 's-rm', 'aria-label': 'ลบ ' + i.name, onclick: () => { cart.remove(i.id); render(); } }, 'ลบ')));
    });
    body.append(list);
    // zone
    // ★Rev.20 job area like a postal form (addrpick.js): search or step by step → zone + travel at once
    const ap = addrPicker({ id: 's-cart-zone', cascade: true, value: cart.addr || cart.zoneInput,
      onPick: (a, z, how) => { cart.setAddr(a, how === 'type' ? ap.input.value : ''); sumBox.replaceWith(sumBox = summary()); } });
    body.append(h('div', { class: 's-field s-area' }, h('label', { for: 's-cart-zone' }, 'พื้นที่หน้างาน (แขวง/ตำบล · เขต/อำเภอ · รหัสไปรษณีย์)'), ap.el));
    let sumBox = summary(); body.append(sumBox);
    function summary() {
      const t = cart.totals();
      return h('dl', { class: 's-sum' },
        h('dt', {}, 'รวมรายการ (ก่อน VAT)'), h('dd', {}, baht(t.ex)),
        t.travel ? [h('dt', {}, t.travelLabel || 'ค่าเดินทาง'), h('dd', {}, baht(t.travel))] : null,
        t.visit ? [h('dt', {}, t.visitLabel), h('dd', {}, baht(t.visit))] : null,
        t.visitSmall ? h('p', { class: 's-note', style: 'grid-column:1/-1' }, t.visit ? `งานย่อยอย่างเดียวมียอดขั้นต่ำต่อการเข้างาน ${baht(SMALL_VISIT.minEx)} ก่อน VAT รายการที่ทำนับรวมแล้ว · ถ้าทำพร้อมงานล้าง ติดตั้ง หรือตรวจซ่อมในวันเดียวกัน ไม่มีค่าเข้างานนี้` : `รายการถึงยอดขั้นต่ำต่อการเข้างาน ${baht(SMALL_VISIT.minEx)} แล้ว ไม่มีค่าเข้างานเพิ่ม`) : null,
        t.travelSmall && cart.zone?.tier !== 'extended' ? h('p', { class: 's-note', style: 'grid-column:1/-1' }, `งานล้างครบ ${baht(DATA.minBill)} ก่อน VAT ไม่มีค่าเดินทางในพื้นที่หลัก (ตอนนี้ ${baht(t.cleanEx)})`) : null,
        h('dt', {}, 'VAT 7%'), h('dd', {}, baht(t.vat)),
        h('dt', { class: 'tot' }, 'รวมทั้งสิ้น'), h('dd', { class: 'tot' }, baht(t.inc)),
        t.surveys ? h('p', { class: 's-note', style: 'grid-column:1/-1' }, `+ ${t.surveys} รายการประเมินหน้างาน ทีมแจ้งราคาให้ยืนยันก่อนเริ่มงาน`) : null,
        cart.zone && cart.zone.tier === 'out' ? h('p', { class: 's-note bad', style: 'grid-column:1/-1' }, 'พื้นที่นี้เกินระยะรับงานรายเครื่อง ส่งข้อมูลได้ ทีมจะประเมินเป็นงานโครงการ') : null);
    }
    body.append(h('p', { class: 's-note' }, 'ราคาตาม Pricebook 2569 ของบริษัท ยืนยันอีกครั้งในใบเสนอราคาอย่างเป็นทางการ รายการเครื่องต้องยืนยันสต็อกก่อนสั่ง'));
    // ★Rev.16 booking: when · site conditions + photos (ticket.js) · who — one form, kept in cart.draft between renders
    const D = cart.draft, jobs = jobsIn(cart.items), visit = visitLines(cart.items);
    const step = (n, t, sub) => h('p', { class: 's-step' }, h('span', {}, String(n)), t, sub ? h('small', {}, sub) : null);
    let dh = dateHint(cart.prefDate, cart.items.some(i => i.group === 'rush'));
    const J = judge(cart.prefDate, visit, 'C1');
    // ★Rev.19 live queue (back office "คิว" tab, queue.js): a full slot shows as full; unknown = the team confirms (never a made-up free slot)
    if (visit.length && !liveAsked) { liveAsked = true; fetchSlots().then(d => { liveQ = d; if (d && !dr.hidden) render(); }); }
    const full = id => slotFree(liveQ, cart.prefDate, id) === false, thOf = id => SLOTS[id].th;
    if (cart.prefDate && J.slots.length && (!J.slots.map(thOf).includes(cart.prefSlot) || full(J.slots.find(id => thOf(id) === cart.prefSlot)))) cart.prefSlot = thOf(J.slots.find(id => !full(id)) || J.slots[0]);
    const slotRow = visit.length && J.slots.length ? h('div', { class: 'qc-seg qc-slot', role: 'radiogroup', 'aria-label': 'ช่วงเวลา' }, J.slots.map(id => h('button', { type: 'button', role: 'radio', 'aria-checked': String(cart.prefSlot === thOf(id)), class: (cart.prefSlot === thOf(id) ? 'on' : '') + (full(id) ? ' full' : ''), disabled: full(id) || null,
      onclick: () => { cart.prefSlot = thOf(id); cart.saveDraft(); render(); } }, h('b', {}, thOf(id)), h('small', {}, full(id) ? 'คิวเต็มแล้ว' : SLOTS[id].sub)))) : null;
    const allFull = visit.length && cart.prefDate && J.slots.length && J.slots.every(full);
    let altDay = ''; if (allFull) for (let i = 1, d = addDays(cart.prefDate, 1); i <= 21 && !altDay; i++, d = addDays(d, 1)) if (isOpen(d) && J.slots.some(id => slotFree(liveQ, d, id) !== false)) altDay = d;
    const liveNote = !visit.length || !cart.prefDate || !liveQ ? null : allFull
      ? h('p', { class: 's-note bad' }, 'ตารางคิวของทีมแสดงว่าวันนี้เต็มแล้ว', altDay ? [' · ', h('button', { type: 'button', class: 'qc-alt', onclick: () => { cart.prefDate = altDay; syncRush(altDay); cart.saveDraft(); render(); } }, `ว่างใกล้สุด ${dateTh(altDay)}`)] : null)
      : slotFree(liveQ, cart.prefDate, J.slots.find(id => thOf(id) === cart.prefSlot)) === true ? h('p', { class: 's-note' }, 'มีคิวว่างตามตารางคิวของทีม ณ ตอนนี้ (ทีมยืนยันอีกครั้ง)') : null;
    const whenBox = h('div', { class: 's-when' }, step(visit.length ? 2 : 1, 'วันเข้างาน', visit.length ? `จองปกติล่วงหน้า ${LEAD_DAYS} วัน` : null),
      h('label', { class: 's-field' }, visit.length && cart.prefSlot ? `วันที่สะดวก · ${cart.prefSlot}` : 'วันที่สะดวก', h('input', { id: 's-q-date', type: 'date', min: bkkNow().date, value: cart.prefDate || null, onchange: e => { cart.prefDate = e.target.value; syncRush(cart.prefDate); cart.saveDraft(); render(); } })),
      dh, slotRow, liveNote, visit.length && cart.prefDate && J.kind !== 'past' && J.time[1] > 0 ? h('p', { class: 's-note' }, `เวลาหน้างานโดยประมาณ ${timeTh(J.time)} · ${J.fit.kind === 'half' ? 'ไม่เกินครึ่งวัน' : J.fit.kind === 'day' ? 'ประมาณ 1 วันทำการ' : `ประมาณ ${J.fit.days} วันทำการ (ช่าง 1 ทีม)`}${J.time[2] ? ' · บางรายการทีมยืนยันเวลาหน้างาน' : ''}`, h('small', { class: 's-tnote' }, TIME_NOTE))
        : visit.length && cart.prefDate && J.kind !== 'past' && J.time[2] ? h('p', { class: 's-note' }, 'เวลาหน้างานของรายการนี้ ทีมประเมินและยืนยันก่อนนัด') : null);   // rule 22: always with TIME_NOTE
    body.append(whenBox);
    if (jobs.clean || jobs.install || jobs.repair) body.append(step(3, 'สภาพหน้างาน + รูป', 'ให้ทีมประเมินงานนอกมาตรฐานก่อนนัด'), ticketPanel(D, jobs, { onChange: () => cart.saveDraft() }));
    if (tiOf(D)) { const tb = h('div', { class: 'tk-diag ti-box' }, h('p', { class: 'tk-l' }, 'ข้อมูลเทิร์นแอร์เก่า', h('small', {}, ' · ส่งไปกับคำขอ ทีมยืนยันมูลค่าเมื่อตรวจเครื่อง')),
      h('ul', {}, tiOf(D).split('\n').map(x => h('li', {}, x)))); body.append(tb); }
    const keep = () => cart.saveDraft();
    const inp = (id, k, attrs) => h('input', { id, value: D[k] || '', oninput: e => { D[k] = e.target.value; keep(); }, ...attrs });
    const isJob0 = !!(jobs.clean || jobs.install || jobs.repair);
    // Rev.16.1: where exactly — the team plans the route, parking and the travel band from this (map link optional)
    const geoOut = h('small', { class: 's-geo-o', 'aria-live': 'polite' });
    const mapIn = inp('s-q-map', 'map', { inputmode: 'url', placeholder: 'วางลิงก์ Google Maps หรือกด "ใช้ตำแหน่งปัจจุบัน"' });
    const where = isJob0 ? h('div', { class: 's-where' },
      h('label', { class: 's-field' }, 'ที่อยู่หน้างาน', h('textarea', { id: 's-q-addr', rows: 2, placeholder: 'บ้านเลขที่ หมู่บ้าน/อาคาร ชั้น ห้อง ซอย ถนน', oninput: e => { D.addr = e.target.value; keep(); } }, D.addr || '')),
      h('label', { class: 's-field' }, 'ตำแหน่งบนแผนที่ (ไม่บังคับ)', mapIn),
      'geolocation' in navigator ? h('button', { type: 'button', class: 's-btn ghost s-geo', onclick: () => { geoOut.textContent = 'กำลังหาตำแหน่ง…';
        navigator.geolocation.getCurrentPosition(p => { D.map = `https://maps.google.com/?q=${p.coords.latitude.toFixed(6)},${p.coords.longitude.toFixed(6)}`; mapIn.value = D.map; keep(); geoOut.textContent = 'ใส่ตำแหน่งแล้ว (ใช้เฉพาะงานนี้)'; },
          () => { geoOut.textContent = 'ใช้ตำแหน่งไม่ได้ — วางลิงก์แผนที่แทนได้'; }, { enableHighAccuracy: true, timeout: 10000 }); } }, 'ใช้ตำแหน่งปัจจุบัน') : null, geoOut) : null;
    const err = h('p', { class: 's-note bad s-err', role: 'alert' });
    const f = h('form', { class: 's-form' },
      step(jobs.clean || jobs.install || jobs.repair ? 4 : 2, 'ผู้ติดต่อ'),
      h('label', { class: 's-field' }, 'ชื่อ / บริษัท', inp('s-q-name', 'name', { required: true, autocomplete: 'name' })),
      h('label', { class: 's-field' }, 'เบอร์โทร', inp('s-q-tel', 'tel', { required: true, inputmode: 'tel', pattern: '[0-9\\- ]{9,12}', autocomplete: 'tel' })),
      isJob0 ? h('div', { class: 's-row2' },
        h('label', { class: 's-field' }, 'LINE ID (ถ้ามี)', inp('s-q-line', 'line', { autocomplete: 'off', placeholder: 'ให้ทีมทักไปส่งราคาและยืนยันคิว' })),
        h('label', { class: 's-field' }, 'สะดวกให้ติดต่อ', h('select', { id: 's-q-when', onchange: e => { D.when = e.target.value; keep(); } }, ['ช่วงเวลาทำการ', 'ช่วงเช้า', 'ช่วงบ่าย', 'ทัก LINE ก่อน'].map(x => h('option', { selected: D.when === x }, x))))) : null,
      where,
      h('label', { class: 's-field' }, 'ต้องการใบกำกับภาษีในนาม', inp('s-q-tax', 'tax', { placeholder: 'ชื่อบริษัท / เลขผู้เสียภาษี (ถ้ามี)' })),
      err, honeypot(), h('button', { class: 's-btn primary', type: 'submit' }, jobs.clean || jobs.install || jobs.repair ? 'ส่งใบจองงาน' : canSend() ? 'ส่งขอใบเสนอราคาอย่างเป็นทางการ' : 'ขอใบเสนอราคาอย่างเป็นทางการ'), privacyNote());
    f.addEventListener('submit', e => {
      e.preventDefault(); const v = id => (f.querySelector('#' + id)?.value || '').trim(), isJob = !!(jobs.clean || jobs.install || jobs.repair), ref = (isJob ? 'B' : 'Q') + Date.now().toString().slice(-7);
      if (isJob) {   // Rev.16.1: a job ticket needs a date and where it is (zone for travel, address for the crew)
        const miss = !cart.prefDate ? ['s-q-date', 'เลือกวันเข้างาน'] : judge(cart.prefDate, [], 'C1').kind === 'past' ? ['s-q-date', 'วันที่เลือกผ่านมาแล้ว'] : !cart.zoneInput || !cart.zone || cart.zone.tier === 'unknown' ? ['s-cart-zone', 'เลือกพื้นที่หน้างาน (แขวง/ตำบล เขต/อำเภอ) ด้านบน'] : !v('s-q-addr') ? ['s-q-addr', 'กรอกที่อยู่หน้างาน'] : allFull ? ['s-q-date', 'วันที่เลือกคิวเต็มแล้ว เลือกวันอื่น'] : null;
        if (miss) { err.textContent = miss[1]; const el = document.getElementById(miss[0]); if (el) { el.scrollIntoView({ block: 'center' }); el.focus({ preventScroll: true }); } return; }
      }
      const t = cart.totals(), sc = (D.scope || []).flatMap(x => x.r.lines), scEx = (D.scope || []).reduce((n, x) => n + x.r.est, 0);
      const tk = isJob ? ticketText(D) : '', ti = tiOf(D);   // Rev.26: the trade-in record travels with quotes and bookings
      prev = null; sent = { state: 'pending', snap: new Map(cart.items.map(i => [i.id, i.qty])), ref, rid: newRid(), isJob, hp: f.querySelector('[name="website"]')?.value || '', photos: isJob ? D.photos.slice() : [],
        fields: { 'ชื่อ / บริษัท': v('s-q-name'), 'โทร': v('s-q-tel'), 'วันที่สะดวก': cart.prefDate || '', 'ช่วงเวลา': visit.length ? cart.prefSlot || '' : '', 'ใบกำกับภาษีในนาม': v('s-q-tax'), 'พื้นที่': cart.zoneInput || '', 'แขวง/ตำบล': cart.addr?.s || '', 'เขต/อำเภอ': cart.addr?.d || cart.zone?.district || '', 'จังหวัด': cart.addr?.p || cart.zone?.province || '', 'รหัสไปรษณีย์': cart.addr?.z || '', 'ระยะถนนประมาณ (กม.)': cart.zone?.km ?? '', 'ค่าเดินทาง (ก่อน VAT)': t.travel, 'จำนวนรายการ': cart.items.length, 'ยอดประมาณการรวม VAT': Math.round(t.inc), 'ข้อมูลเทิร์นแอร์เก่า': ti,
          ...(isJob ? { 'งาน': [jobs.clean ? `ล้าง ${jobs.clean} เครื่อง` : '', jobs.install ? `ติดตั้ง ${jobs.install} เครื่อง` : '', jobs.repair ? `ซ่อม / ตรวจเช็ก ${jobs.repair} รายการ` : ''].filter(Boolean).join(' · '), 'ขอบเขต': sc.length ? `เกินมาตรฐาน ${sc.length} จุด` : 'มาตรฐาน', 'ส่วนเพิ่มประมาณ (ก่อน VAT)': Math.round(scEx), 'จำนวนรูป': D.photos.length, 'หมายเหตุหน้างาน': D.note || '', 'ผลประเมินเบื้องต้น (ผู้ช่วย)': (jobs.repair && D.diag && D.diag.text) || '', 'ที่อยู่หน้างาน': v('s-q-addr'), 'แผนที่': v('s-q-map'), 'LINE ID': v('s-q-line'), 'สะดวกให้ติดต่อ': D.when || 'ช่วงเวลาทำการ' } : {}) },
        text: [`${isJob ? 'ใบจองงาน' : 'ขอใบเสนอราคาอย่างเป็นทางการ'} · เลขอ้างอิง ${ref}`, `ชื่อ / บริษัท: ${v('s-q-name')}`, `โทร: ${v('s-q-tel')}`, isJob && v('s-q-line') ? `LINE ID: ${v('s-q-line')}` : null, isJob ? `สะดวกให้ติดต่อ: ${D.when || 'ช่วงเวลาทำการ'}` : null, isJob ? `ที่อยู่หน้างาน: ${v('s-q-addr')}${cart.zoneInput ? ' (' + cart.zoneInput + ')' : ''}` : null, isJob && v('s-q-map') ? `แผนที่: ${v('s-q-map')}` : null, cart.prefDate ? `วันเข้างาน: ${dateTh(cart.prefDate)} (${cart.prefDate})${visit.length && cart.prefSlot ? ' · ' + cart.prefSlot : ''}` : null, v('s-q-tax') ? `ใบกำกับภาษีในนาม: ${v('s-q-tax')}` : null, '', quoteText(), tk ? '' : null, tk || null, ti ? '' : null, ti ? '— ข้อมูลเทิร์นแอร์เก่า (ทีมยืนยันมูลค่าเมื่อตรวจเครื่อง) —' : null, ti || null].filter(x => x != null).join('\n') };
      render();
    });
    body.append(f);
    body.append(h('button', { type: 'button', class: 's-btn ghost', onclick: async () => { toast((await copyText(quoteText())) ? 'คัดลอกสรุปแล้ว วางในอีเมลหรือแชตได้' : 'คัดลอกไม่ได้ในหน้านี้'); } }, 'คัดลอกสรุปรายการ'));
  }
  // ★Rev.28 add-to-quote feedback: the quote buttons and the floating pill pop when the count grows (CSS .s-bump, motion-safe)
  let lastN = null;
  const bump = el => { if (!el) return; el.classList.remove('s-bump'); void el.offsetWidth; el.classList.add('s-bump'); clearTimeout(el._bump); el._bump = setTimeout(() => el.classList.remove('s-bump'), 650); };
  const upd = () => { const n = cart.count(), grew = lastN != null && n > lastN; lastN = n;
    $$(buttons).forEach(b => { b.dataset.n = n; const c = $('[data-cart-n]', b); if (c) c.textContent = n; b.classList.toggle('has', n > 0); b.setAttribute('aria-label', `ใบเสนอราคา ${n} รายการ`); if (grew) bump(b); });
    if (grew) bump(document.querySelector('.s-qpill:not([hidden])')); };
  cart.subs.add(upd); upd();
  cart.subs.add(() => { if (moveOn() && !dr.hidden) render(); });   // ★Rev.33 after the count bump, so the quote button still pops
  $$(buttons).forEach(b => b.addEventListener('click', open));
  return { open, close, render };
}

/* =========================================================
   Product detail: specs + install package + add-ons + live total
   ========================================================= */
export function productDetail(m, skuIndex, { onPick, on3D, onAdded, onFit } = {}) {
  const b = BRAND_BY_ID[m.brand], t = TYPE_BY_ID[m.type], s = m.skus[skuIndex], d = s.d;
  const opts = installOptions(m.type, s.btu);
  const std = opts.find(o => o.key === 'STANDARD');
  const state = { level: std ? 'STANDARD' : opts[0]?.key || null, qty: 1, add: {} };
  const root = h('div', { class: 's-pd' });
  root.append(
    productVisual(m, s, { size: 'detail' }),   // Rev.09: photo slot (assets/product-media.json) or studio render
    h('p', { class: 's-pd-brand' }, b.name, ' · ', t.th, d.system ? ' · ' + d.system : ''),
    h('h3', { class: 's-pd-title' }, s.sku),
    h('p', { class: 's-pd-meta' }, `${d.series || ''} · ${btuFmt(s.btu)} · น้ำยา ${d.refrigerant || '—'}`),
  );
  const chips = h('div', { class: 'btu-chips s-chips', role: 'radiogroup', 'aria-label': 'เลือกขนาด BTU' });
  m.skus.forEach((k, i) => chips.append(h('button', { type: 'button', role: 'radio', 'aria-checked': i === skuIndex, class: 'bchip', onclick: () => onPick && onPick(i) }, k.btu.toLocaleString())));
  root.append(chips);
  // price block
  root.append(h('div', { class: 's-pd-price' }, h('span', { class: 's-lbl' }, 'ราคาเครื่อง'), priceNode(s.px), h('small', { class: 's-note' }, stockTh(s) + (d.approved ? ' · ราคาอนุมัติ Pricebook 2569' : ' · ราคาอ้างอิงตลาด ต้องยืนยันก่อนเสนอ'))));
  // install package
  if (opts.length) {
    const box = h('fieldset', { class: 's-pkg' }, h('legend', {}, 'แพ็กเกจติดตั้ง'));
    const list = h('div', { class: 's-pkg-list' });
    const none = { key: null, th: 'ไม่ติดตั้ง / ซื้อเครื่องอย่างเดียว' };
    [...opts, none].forEach(o => {
      const id = `pk-${m.id}-${o.key || 'none'}`;
      const inp = h('input', { type: 'radio', name: `pk-${m.id}`, id, checked: state.level === o.key });
      inp.addEventListener('change', () => { state.level = o.key; refresh(); });
      list.append(h('label', { class: 's-pkg-o', for: id }, inp, h('span', {}, h('b', {}, o.th), o.note ? h('small', {}, o.note) : null), o.item ? priceNode(o.item.ex) : h('span', { class: 's-price' }, '—')));
    });
    box.append(list);
    const det = h('details', { class: 's-det' }, h('summary', {}, 'รายละเอียดสิ่งที่รวม / ไม่รวม'), h('div', { class: 's-det-b' }));
    box.append(det);
    box.append(h('details', { class: 's-det' }, h('summary', {}, 'เทียบวัสดุ มาตรฐาน / พรีเมียม (ยี่ห้อ · สเปก · การทดสอบ)'), materialTable(m.type, s.btu, { compact: true })));
    root.append(box);
    var detBody = $('.s-det-b', det);
  }
  // add-ons
  const addWrap = h('div', { class: 's-add' }, h('h3', {}, 'อุปกรณ์และงานเพิ่มเติม'));
  addonsFor(m.type, s.btu).forEach(g => {
    const grp = h('div', { class: 's-add-g' }, h('p', { class: 's-lbl' }, g.group));
    g.items.forEach((a, idx) => {
      const key = `${g.group}-${idx}`;
      if (a.qty === 'flag') {
        const id = `ad-${m.id}-${a.item.code}`;
        const cb = h('input', { type: 'checkbox', id });
        cb.addEventListener('change', () => { state.add[key] = cb.checked ? { item: a.item, qty: 1, flag: true } : null; refresh(); });
        grp.append(h('label', { class: 's-add-r flag', for: id }, cb, h('span', {}, a.item.name), h('span', { class: 's-price survey' }, 'ประเมินหน้างาน')));
        return;
      }
      const choices = a.choose || [a.item];
      let cur = choices[0];
      const qty = h('input', { type: 'number', min: '0', max: '99', value: '0', inputmode: 'numeric', 'aria-label': 'จำนวน' });
      const sel = choices.length > 1 ? h('select', { 'aria-label': 'เลือกรายการ' }, choices.map((c, i) => h('option', { value: i }, `${c.name.replace(/^งานเดินเมนไฟ 1 เฟส — /, 'เมนไฟ ').replace(/^เซอร์กิตเบรกเกอร์ /, '')} · ${baht(c.ex)}/${c.unit}`))) : null;
      const set = () => { const q = Math.max(0, +qty.value || 0); state.add[key] = q ? { item: cur, qty: q } : null; refresh(); };
      qty.addEventListener('input', set); sel && sel.addEventListener('change', () => { cur = choices[+sel.value]; set(); });
      grp.append(h('div', { class: 's-add-r' }, h('span', { class: 's-add-n' }, sel ? null : cur.name, sel, (a.note || optionNote(cur.code)) ? h('small', {}, a.note || optionNote(cur.code)) : null), h('span', { class: 's-add-u' }, sel ? '' : `${baht(cur.ex)} / ${cur.unit}`), h('label', { class: 's-qty' }, qty, h('span', {}, cur.unit))));
    });
    addWrap.append(grp);
  });
  // Rev.17: what one extra metre of the bundle holds, against the same metre line by line (Pricebook prices, before VAT)
  const pb = pipeBundle(pipeItemFor(m.type, s.btu));
  if (pb && pb.parts) addWrap.append(h('details', { class: 's-det s-bundle' }, h('summary', {}, `ชุดวัสดุส่วนเกิน ${baht(pb.item.ex)} ต่อเมตร มีอะไรบ้าง`),
    h('table', { class: 's-btable' }, h('thead', {}, h('tr', {}, h('th', {}, 'ใน 1 เมตร'), h('th', {}, 'รายการใน Pricebook'), h('th', {}, 'ถ้าซื้อแยก'))),
      h('tbody', {}, pb.parts.map(x => h('tr', {}, h('td', {}, x.th), h('td', {}, x.name + (x.qty > 1 ? ` × ${x.qty}` : '')), h('td', {}, baht(x.ex * x.qty)))),
        h('tr', { class: 'tot' }, h('td', {}, 'รวมถ้าซื้อแยกชิ้น'), h('td', {}, 'ยังไม่รวมค่าแรงเดินท่อ เชื่อม บานแฟลร์'), h('td', {}, baht(pb.sum))),
        h('tr', { class: 'tot' }, h('td', {}, 'ชุดเหมาต่อเมตร'), h('td', {}, 'วัสดุครบชุด + ค่าแรงติดตั้ง'), h('td', {}, h('b', {}, baht(pb.item.ex)))))),
    h('p', { class: 's-note' }, 'ราคาก่อน VAT จาก Pricebook 2569 ของบริษัท · วัสดุคิดตามราคาจริงไม่ปัด · ทีมวัดระยะจริงก่อนติดตั้งและแจ้งก่อนเพิ่มทุกครั้ง')));
  root.append(addWrap);
  // Rev.17: itemised cost — every option as a line: unit price × quantity = amount
  const bd = h('div', { class: 's-bd', 'aria-live': 'polite' });
  root.append(h('details', { class: 's-det s-bd-w', open: true }, h('summary', {}, 'ค่าใช้จ่ายแยกรายการ (ก่อน VAT)'), bd));
  // specs
  const spec = [['รหัสรุ่น', s.sku], ['ซีรีส์', d.series], ['ระบบ', d.system], ['ขนาด', btuFmt(s.btu)], ['น้ำยา', d.refrigerant], ['ท่อน้ำยา', d.pipeLiquid && d.pipeGas ? `${d.pipeLiquid}" / ${d.pipeGas}"` : null], ['คอยล์เย็น (มม.)', d.indoorDim], ['น้ำหนักคอยล์เย็น', d.indoorKg && d.indoorKg + ' กก.'], ['คอยล์ร้อน (มม.)', d.outdoorDim], ['น้ำหนักคอยล์ร้อน', d.outdoorKg && d.outdoorKg + ' กก.'], ['ไฟ', d.power], ['คอมเพรสเซอร์', d.compressor], ['รับประกันเครื่อง', d.warranty]];
  root.append(h('details', { class: 's-det', open: true }, h('summary', {}, 'สเปกเครื่อง'), h('dl', { class: 's-spec' }, spec.filter(([, v]) => v).map(([k, v]) => [h('dt', {}, k), h('dd', {}, v)]))));
  // live total
  const tot = h('div', { class: 's-pd-total', 'aria-live': 'polite' });
  const qtyIn = h('input', { type: 'number', min: '1', max: '99', value: '1', 'aria-label': 'จำนวนเครื่อง', inputmode: 'numeric' });
  qtyIn.addEventListener('input', () => { state.qty = Math.max(1, +qtyIn.value || 1); refresh(); });
  root.append(h('div', { class: 's-pd-buy' }, h('label', { class: 's-qty big' }, h('span', {}, 'จำนวน'), qtyIn, h('span', {}, 'เครื่อง')), tot,
    h('div', { class: 's-pd-cta' },
      h('button', { type: 'button', class: 's-btn primary', onclick: addToCart }, 'ใส่ใบเสนอราคา'),
      onFit ? h('button', { type: 'button', class: 's-btn', onclick: () => onFit(m, m.skus.indexOf(s)) }, 'ลองวางในห้องของคุณ') : null,
      on3D ? h('button', { type: 'button', class: 's-btn ghost', onclick: () => on3D(m, s) }, 'ดูข้างในแบบ 3 มิติ') : null)));
  function lines() {
    const L = [{ kind: 'product', group: 'product', key: `P-${s.sku}`, name: `${b.name} ${s.sku}`, detail: `${t.th} ${btuFmt(s.btu)}`, unitEx: s.px, qty: state.qty }];
    const o = opts.find(o => o.key === state.level);
    if (o) L.push({ kind: 'service', group: 'install', key: `I-${o.item.code}`, name: o.item.name, detail: `สำหรับ ${s.sku}`, unitEx: o.item.ex, qty: state.qty });
    Object.values(state.add).filter(Boolean).forEach(a => L.push(a.flag ? { kind: 'survey', group: 'addon', key: `S-${a.item.code}`, name: a.item.name, detail: `สำหรับ ${s.sku}`, unitEx: null, qty: 1 } : { kind: 'addon', group: 'addon', key: `A-${a.item.code}`, name: a.item.name, detail: `${a.qty} ${a.item.unit} × ${state.qty} เครื่อง`, unitEx: a.item.ex * a.qty, qty: state.qty }));
    return L;
  }
  function refresh() {
    const L = lines();
    const ex = L.reduce((n, l) => n + (l.unitEx == null ? 0 : l.unitEx * l.qty), 0);
    const sv = L.filter(l => l.unitEx == null).length;
    tot.innerHTML = '';
    tot.append(h('span', { class: 's-lbl' }, `รวม ${state.qty} เครื่อง${state.level ? ' พร้อมติดตั้ง' : ''}`), h('b', {}, baht(ex)), h('small', {}, `ก่อน VAT · รวม VAT 7% ${baht(incVat(ex))}${sv ? ` · +${sv} รายการประเมินหน้างาน` : ''}`));
    drawBreakdown();
    if (detBody) { const o = opts.find(o => o.key === state.level); detBody.innerHTML = ''; if (o) detBody.append(h('p', {}, h('b', {}, 'รวม: '), o.item.inc || '—'), h('p', {}, h('b', {}, 'ไม่รวม: '), o.item.exc || '—'), h('p', {}, h('b', {}, 'รับประกัน: '), o.item.warranty || '—')); else detBody.append(h('p', {}, 'ซื้อเครื่องอย่างเดียว ไม่รวมงานติดตั้ง')); }
  }
  function drawBreakdown() {
    const o = opts.find(o => o.key === state.level), Q = state.qty;
    const rows = [{ group: 'product', key: `P-${s.sku}`, name: `${b.name} ${s.sku} (${btuFmt(s.btu)})`, unit: 'เครื่อง', unitEx: s.px, qty: Q }];
    if (o) rows.push({ group: 'install', key: `I-${o.item.code}`, name: o.th || o.item.name, unit: 'เครื่อง', unitEx: o.item.ex, qty: Q });
    Object.values(state.add).filter(Boolean).forEach(a => rows.push(a.flag ? { group: 'addon', key: `S-${a.item.code}`, name: a.item.name, unitEx: null, qty: 1 } : { group: 'addon', key: `A-${a.item.code}`, name: a.item.name, unit: a.item.unit, unitEx: a.item.ex, qty: a.qty * Q }));
    const B = breakdown(rows), parts = o ? packageParts(o.item) : [];
    bd.innerHTML = '';
    B.groups.forEach(g => bd.append(h('div', { class: 's-bd-g' }, h('p', { class: 's-lbl' }, g.th),
      h('ul', {}, g.rows.map(r => h('li', {}, h('span', {}, r.name, r.amount != null && (r.qty > 1 || r.unit !== 'เครื่อง') ? h('small', {}, `${baht(r.ex)} / ${r.unit || 'หน่วย'} × ${r.qty}`) : null, r.note ? h('small', {}, r.note) : null), h('b', {}, r.amount == null ? 'ประเมิน' : baht(r.amount))))),
      g.th === 'แพ็กเกจติดตั้ง' && parts.length ? h('details', { class: 's-bd-inc' }, h('summary', {}, `รวมในแพ็กเกจแล้ว ${parts.length} รายการ`), h('ul', {}, parts.map(x => h('li', {}, x)))) : null)));
    bd.append(h('dl', { class: 's-sum' }, h('dt', {}, 'รวมก่อน VAT'), h('dd', {}, baht(B.ex)), h('dt', {}, 'VAT 7%'), h('dd', {}, baht(B.vat)), h('dt', { class: 'tot' }, 'รวมทั้งสิ้น'), h('dd', { class: 'tot' }, baht(B.inc)),
      B.assess ? h('p', { class: 's-note', style: 'grid-column:1/-1' }, `+ ${B.assess} รายการประเมินหน้างาน — ทีมแจ้งราคาให้อนุมัติก่อนทำ`) : null));
  }
  function addToCart() { const L = lines(); L.forEach(l => cart.add(l)); toast(L.some(l => l.group === 'install') ? `ใส่ใบเสนอราคาแล้ว · เปิดใบเสนอราคาเพื่อเลือกวันติดตั้งและส่งใบจองงาน` : `ใส่ใบเสนอราคาแล้ว · ${cart.count()} รายการ`); onAdded && onAdded(); }
  refresh();
  return root;
}


/* =========================================================
   Material quality: parse the install packages' "included" text into comparable rows
   ========================================================= */
export const MAT_ROWS = [
  { id: 'incl', th: 'ระยะที่รวมในราคา', re: /^รวมท่อ/ },
  { id: 'pipe', th: 'ท่อน้ำยาทองแดง', re: /ท่อน้ำยา|ท่อทองแดง|Type L|K Copper|ทองแดง/ },
  { id: 'ins', th: 'ฉนวนหุ้มท่อ', re: /ฉนวน|Aeroflex|Closed-cell/ },
  { id: 'rail', th: 'รางครอบท่อ', re: /ราง/ },
  { id: 'cable', th: 'สายไฟ', re: /สายไฟ|Yazaki|มอก\./ },
  { id: 'drain', th: 'ท่อน้ำทิ้ง', re: /ท่อน้ำทิ้ง|SCG|PVC/ },
  { id: 'brk', th: 'เบรกเกอร์', re: /Breaker|เบรกเกอร์/ },
  { id: 'mount', th: 'ขาแขวน · กันสั่น', re: /ขาแขวน|ยางรอง|Support|Anti-vibration|กันสั่น/ },
  { id: 'test', th: 'ทดสอบระบบ', re: /Vacuum|Nitrogen|Leak|Torque|Flare|Test Run|ตรวจรอยต่อ|Function/ },
  { id: 'doc', th: 'เอกสาร · ภาพ · ติดตามผล', re: /Photo|ภาพ|ใบรับมอบ|บันทึก|ติดตาม|Commissioning/ },
];
export function materialMatrix(type, btu) {
  const opts = installOptions(type, btu);
  const cols = opts.map(o => {
    const parts = (o.item.inc || '').split(/;\s*/).map(x => x.trim()).filter(Boolean);
    const cell = {};
    // each "; " part may hold several clauses ("Vacuum, ตรวจรอยต่อ…, Test Run และใบรับมอบงาน") — give every clause to ONE row
    // (first matching), and a clause that matches nothing stays with the clause before it
    let lastRow = null;
    parts.forEach(pt => {
      if (/^รวมท่อ/.test(pt)) { (cell.incl = cell.incl || []).push(pt.replace(/^รวม/, '').trim()); return; }
      if (/วัสดุ Standard/.test(pt)) return;
      pt.split(/,\s*|\s+และ(?=\S)/).map(x => x.trim()).filter(Boolean).forEach(cl => {
        const r = MAT_ROWS.slice(1).find(r => r.re.test(cl)) || lastRow; if (!r) return; lastRow = r;
        (cell[r.id] = cell[r.id] || []).push(cl);
      });
    });
    if (parts.some(pt => /วัสดุ Standard/.test(pt))) MAT_ROWS.slice(1, 8).forEach(r => { cell[r.id] = cell[r.id] ? ['เหมือนแพ็กเกจมาตรฐาน', ...cell[r.id]] : ['เหมือนแพ็กเกจมาตรฐาน']; });
    return { key: o.key, th: o.th, item: o.item, cell };
  });
  return cols;
}
export function materialTable(type, btu, { compact = false } = {}) {
  const cols = materialMatrix(type, btu);
  if (!cols.length) return h('p', { class: 's-note' }, 'ขนาดนี้ต้องสำรวจก่อนระบุวัสดุ');
  const t = h('table', { class: 's-mat' + (compact ? ' compact' : '') },
    h('thead', {}, h('tr', {}, h('th', {}, 'รายการ'), cols.map(c => h('th', { class: c.key === 'STANDARD' ? 'rec' : '' }, c.th, c.key === 'STANDARD' ? h('small', {}, 'แนะนำ') : null, h('span', { class: 's-mat-p' }, baht(c.item.ex)))))),
    h('tbody', {},
      MAT_ROWS.map(r => h('tr', {}, h('th', { scope: 'row' }, r.th), cols.map(c => h('td', { class: c.key === 'STANDARD' ? 'rec' : '' }, c.cell[r.id] ? c.cell[r.id].join(' · ') : '—')))),
      h('tr', {}, h('th', { scope: 'row' }, 'รับประกันงานติดตั้ง'), cols.map(c => h('td', { class: c.key === 'STANDARD' ? 'rec' : '' }, c.item.warranty || '—')))));
  return h('div', { class: 's-mat-wrap', tabindex: '0', role: 'region', 'aria-label': 'ตารางเทียบวัสดุ เลื่อนดูด้านข้างได้' }, t);
}
export function mountMaterials(root, cfg = {}) {
  let type = 'wall', btu = 12000;
  const show = h('div', { class: 'mt3-root' }); root.append(show);
  import('./materials3d.js').then(m => m.mountMaterials3D(show, { theme: cfg.theme })).catch(e => console.warn('materials showcase', e));
  mountMatCards(root);   // Rev.26 brand spec cards + animated cut-aways
  const sizes = { wall: [12000, 18000, 24000, 30000], ceiling: [24000, 36000, 48000, 60000], cassette: [24000, 36000, 48000, 60000], floor: [36000, 48000, 60000] };
  const bar = h('div', { class: 's-seg', role: 'group', 'aria-label': 'ประเภทเครื่อง' });
  const sz = h('div', { class: 's-seg', role: 'group', 'aria-label': 'ขนาด' });
  const out = h('div');
  const why = h('div', { class: 's-why' },
    h('h3', {}, 'ก่อนจ้างติดตั้ง ไม่ว่าร้านไหน ควรถาม 6 ข้อนี้'),
    h('ol', {}, ['ท่อทองแดงหนากี่มิลลิเมตร และยี่ห้ออะไร', 'ฉนวนหุ้มท่อยี่ห้อและความหนาเท่าไร', 'สายไฟยี่ห้อ ขนาด และมีเบรกเกอร์แยกหรือไม่', 'ทำ Vacuum ก่อนปล่อยน้ำยาหรือไม่ ใช้เวลาเท่าไร', 'ราคารวมท่อกี่เมตร ส่วนเกินคิดเมตรละเท่าไร', 'รับประกันงานติดตั้งกี่ปี ครอบคลุมอะไร'].map(x => h('li', {}, x))),
    h('p', { class: 's-note' }, 'ทุกข้อด้านซ้ายเราระบุไว้ในแพ็กเกจและในใบเสนอราคาแล้ว ลูกค้าตรวจของจริงหน้างานเทียบกับเอกสารได้'));
  function render() {
    bar.innerHTML = ''; sz.innerHTML = '';
    [['wall', 'ติดผนัง'], ['ceiling', 'แขวนใต้ฝ้า'], ['cassette', 'สี่ทิศทาง'], ['floor', 'ตู้ตั้งพื้น']].forEach(([id, th]) => bar.append(h('button', { type: 'button', 'aria-pressed': id === type, onclick: () => { type = id; btu = sizes[id][0]; render(); } }, th)));
    sizes[type].forEach(b => sz.append(h('button', { type: 'button', 'aria-pressed': b === btu, onclick: () => { btu = b; render(); } }, (b / 1000) + 'k BTU')));
    out.innerHTML = ''; out.append(materialTable(type, btu));
  }
  root.append(h('div', { class: 's-mat-tools' }, bar, sz), h('div', { class: 's-mat-grid' }, out, why), h('p', { class: 's-note' }, 'ข้อมูลจากแพ็กเกจติดตั้งใน Pricebook 2569 ราคาต่อเครื่องก่อน VAT รวมท่อและวัสดุ 4 เมตรแรก ทุกแพ็กเกจบนเว็บใช้วัสดุเกรดพรีเมียมชุดเดียวกัน · ท่อน้ำยาทองแดง O-TWO หนา 0.70 มม. ทุกงาน'));
  render();
}


/* =========================================================
   Cleaning packages — what each level gives, who it suits, starting prices (Pricebook) — from sales manual SBP-SAL-001
   ========================================================= */
export const PKG_INFO = [
  { id: 'Basic Clean', code: 'P1', th: 'ล้างมาตรฐาน', pitch: 'คุ้มค่า', fit: 'บ้าน คอนโด ร้านเล็ก ที่ต้องการล้างตามรอบ', gets: ['ใบรับมอบงาน / รายงานแบบย่อรายเครื่อง', 'ทดสอบการทำงาน น้ำทิ้ง และ Error Code หลังล้าง (T1)'], care: 'ไม่มี' },
  { id: 'Standard Care', code: 'P2', th: 'ล้างพร้อมรายงานภาพ', pitch: 'มีหลักฐาน วางแผนซ่อมได้', fit: 'สำนักงาน ร้านค้า คลินิก ร้านอาหาร ที่ต้องการเอกสารและภาพ', gets: ['Service Report พร้อมภาพ 2–4 ภาพต่อเครื่อง', 'วัดค่าก่อน–หลัง (T2): ลมกลับ ลมจ่าย ผลต่างอุณหภูมิ กระแส แรงดัน', 'ประเมินสภาพเครื่อง A–D + สรุปโครงการ'], care: 'Service Care 90 วัน' },
  { id: 'Corporate Control', code: 'P3', th: 'ล้างพร้อมทะเบียนทรัพย์สิน', pitch: 'บริหารทรัพย์สิน', fit: 'องค์กรหลายสาขา โรงงาน โรงแรม โรงพยาบาล', gets: ['ทะเบียนทรัพย์สิน รุ่น / หมายเลขเครื่อง รายเครื่อง', 'ดัชนีภาพ + ค่าตรวจวัดเชื่อมกับทะเบียน (T3)', 'จัดลำดับความสำคัญ แนวโน้ม ผู้รับผิดชอบ กำหนดปิดเคส'], care: 'Service Care Plus 90 วัน' },
];
export const METHOD_INFO = [
  { id: 'C1', th: 'ล้างปกติ (C1)', d: 'ล้างที่ตำแหน่งเดิม ล้างจุดบริการและส่วนที่เข้าถึงได้ ไม่ปลดเครื่อง ไม่เปิดวงจรน้ำยา' },
  { id: 'C2', th: 'ล้างใหญ่ (C2)', d: 'ปลดคอยล์เย็นลงล้างโดยไม่ตัดท่อน้ำยา ถอดใบพัดโบลเวอร์และถาดน้ำทิ้งตามทะเบียนชิ้นส่วนที่ถอด (ไม่รวมมอเตอร์ แผงวงจร และการเปิดวงจรน้ำยา)' },
  { id: 'C3', th: 'ตัดล้าง (C3)', d: 'สำรวจก่อนเสมอ รวมทดสอบรั่ว Vacuum และ Commissioning ตามใบเสนอราคา ไม่มีราคามาตรฐานบนเว็บ' },
];
export function cleanPackageGuide(where = 'บริการ', hl = 'h4') {   // hl = heading level for the cards (depends on where it sits)
  let method = 'C1';
  const root = h('div', { class: 'pk' });
  const types = [['wall', 'ติดผนัง'], ['ceiling', 'แขวนใต้ฝ้า'], ['cassette', 'สี่ทิศทาง'], ['floor', 'ตั้งพื้น/ตั้งตู้'], ['duct', 'ซ่อนในฝ้า/ท่อลม']];
  const startAt = (pkg, lv) => { const rs = DATA.clean.filter(r => r.pkg === pkg && r.level === lv && r.type && r.rate.s != null); return rs.length ? Math.min(...rs.map(r => r.rate.s)) : null; };
  function render() {
    root.innerHTML = '';
    const cards = h('div', { class: 'pk-cards' }, PKG_INFO.map(p => { const r = DATA.clean.find(x => x.pkg === p.id && x.type); const from = startAt(p.id, 'C1');
      return h('article', { class: 'pk-card' + (p.code === 'P2' ? ' rec' : '') }, h('p', { class: 'pk-code' }, `${p.code} · ${p.id}`, p.code === 'P2' ? h('span', {}, 'แนะนำสำหรับธุรกิจ') : null), h(hl, {}, p.th), h('p', { class: 'pk-pitch' }, p.pitch),
        h('p', { class: 'pk-from' }, h('small', {}, 'ล้างปกติ เริ่ม'), h('b', {}, from ? baht(from) : '—'), h('small', {}, '/ เครื่อง ก่อน VAT')),
        h('ul', {}, p.gets.map(g => h('li', {}, g))), h('dl', {}, h('dt', {}, 'รับประกันงานล้าง'), h('dd', {}, r?.warranty || '—'), h('dt', {}, 'ดูแลหลังบริการ'), h('dd', {}, p.care), h('dt', {}, 'เหมาะกับ'), h('dd', {}, p.fit))); }));
    const methods = h('div', { class: 'pk-methods' }, METHOD_INFO.map(m => h('div', {}, h('b', {}, m.th), h('p', {}, m.d))));
    const seg = h('div', { class: 's-seg', role: 'group', 'aria-label': 'วิธีล้าง' }, [['C1', 'ล้างปกติ C1'], ['C2', 'ล้างใหญ่ C2']].map(([k, t]) => h('button', { type: 'button', 'aria-pressed': k === method, onclick: () => { method = k; render(); } }, t)));
    const tb = h('tbody');
    types.forEach(([t, th]) => { const bands = SIZE_BANDS.filter(b => DATA.clean.some(r => r.type === t && r.range === (t === 'wall' ? b.wall : b.other)));
      bands.forEach((b, i) => { const rg = t === 'wall' ? b.wall : b.other; tb.append(h('tr', {}, i === 0 ? h('th', { rowspan: bands.length, scope: 'rowgroup' }, th) : null, h('td', {}, rg + ' BTU'), ...PKG_INFO.map(p => { const r = DATA.clean.find(x => x.pkg === p.id && x.level === method && x.type === t && x.range === rg); return h('td', { class: 'pr' }, r && r.rate.s != null ? baht(r.rate.s) : 'ประเมิน'); }))); }); });
    root.append(cards,
      h('div', { class: 'pk-key' }, h('b', {}, 'ระดับบริการแพงขึ้น ไม่เท่ากับล้างลึกขึ้น: '), 'ความลึกของการล้างอยู่ที่วิธีล้าง C1 / C2 ส่วน P1 / P2 / P3 คือหลักฐาน การตรวจวัด การรับประกัน และการดูแลหลังงาน เลือกได้อิสระ เช่น P3 + ล้างปกติ'),
      methods,
      h('div', { class: 'pk-table-h' }, h(hl, {}, 'ราคาต่อเครื่อง (ก่อน VAT) ตามประเภทและขนาด'), seg),
      h('div', { class: 'pk-scroll', tabindex: '0', role: 'region', 'aria-label': 'ตารางราคาล้างต่อเครื่อง (' + where + ')' }, h('table', { class: 'pk-t' }, h('thead', {}, h('tr', {}, h('th', {}, 'ประเภท'), h('th', {}, 'ขนาด'), ...PKG_INFO.map(p => h('th', {}, p.id)))), tb)),
      h('p', { class: 's-note' }, `ราคามาตรฐานจาก Pricebook 2569 · ขั้นต่ำต่อการเข้าหน้างาน ${baht(DATA.minBill)} · งานเสริมตามอาการ (น้ำยาล้างคอยล์เกรดอุตสาหกรรม, Chemical Wash สเปรย์โฟมเกรด อย., ตรวจระบบน้ำยา) เสนอราคาแยกเมื่อจำเป็น · Service Care คือสิทธิ์ดูแลหลังส่งมอบตามเงื่อนไขในใบเสนอราคา ไม่ใช่การรับประกัน · อัตราพิเศษตามจำนวนเครื่องยืนยันในใบเสนอราคา`));
  }
  render();
  return root;
}
/* =========================================================
   Service price centre
   ========================================================= */
export function mountPriceCenter(root) {
  const tabs = [
    { id: 'clean', th: 'ล้างแอร์' }, { id: 'install', th: 'ติดตั้ง' }, { id: 'repair', th: 'ซ่อม' },
    { id: 'contract', th: 'สัญญาล้างรายปี' }, { id: 'move', th: 'รื้อ · ย้าย · น้ำยา · งานพิเศษ' }, { id: 'mat', th: 'วัสดุและอุปกรณ์เสริม' }, { id: 'project', th: 'งานโครงการ · รีโนเวท' },
  ];
  let tab = 'clean', pkg = 'Standard Care', level = 'C1', insLevel = 'STANDARD', q = '';
  const bar = h('div', { class: 's-tabs', role: 'tablist', 'aria-label': 'หมวดค่าบริการ' });
  const tools = h('div', { class: 's-pc-tools' });
  const search = h('input', { class: 's-search', id: 'pc-search', placeholder: 'ค้นหารายการ เช่น ปั๊มน้ำทิ้ง, เบรกเกอร์, คาปาซิเตอร์', autocomplete: 'off', 'aria-label': 'ค้นหาค่าบริการ' });
  search.addEventListener('input', () => { q = search.value.trim().toLowerCase(); body(); });
  const out = h('div', { class: 's-pc-body' });
  root.append(bar, tools, out);
  tabs.forEach(t => { const b = h('button', { type: 'button', role: 'tab', 'aria-selected': t.id === tab, onclick: () => { tab = t.id; head(); body(); } }, t.th); bar.append(b); });
  const seg = (list, val, set, label) => h('div', { class: 's-seg', role: 'group', 'aria-label': label }, list.map(o => h('button', { type: 'button', 'aria-pressed': o.id === val, onclick: () => { set(o.id); head(); body(); } }, o.th, o.sub ? h('small', {}, o.sub) : null)));
  function head() {
    $$('[role=tab]', bar).forEach((b, i) => b.setAttribute('aria-selected', tabs[i].id === tab));
    tools.innerHTML = '';
    if (tab === 'clean') tools.append(seg(CLEAN_PKGS, pkg, v => pkg = v, 'แพ็กเกจ'), seg([{ id: 'C1', th: 'ล้างปกติ C1', sub: 'ล้างตามจุดที่เข้าถึงได้' }, { id: 'C2', th: 'ล้างใหญ่ C2', sub: 'C1 + ถอดล้าง Blower / ถาดน้ำทิ้ง' }], level, v => level = v, 'ระดับการล้าง'));
    if (tab === 'install') tools.append(seg([{ id: 'STANDARD', th: 'มาตรฐาน', sub: 'วัสดุพรีเมียมครบ' }, { id: 'PREMIUM', th: 'พรีเมียม', sub: '+ Support และงานเก็บรายละเอียด' }], insLevel, v => insLevel = v, 'ระดับงานติดตั้ง'));
    tools.append(search);
  }
  const match = (...txt) => !q || txt.join(' ').toLowerCase().includes(q);
  function row({ name, sub, ex, unit, warranty, inc, exc, add }) {
    const vrf = isVRF(name, sub);   // Rev.09: VRV / VRF never goes into the basket — separate inquiry
    const r = h('div', { class: 's-row' + (ex == null ? ' sv' : '') },
      h('div', { class: 's-row-t' }, h('b', {}, name, vrf ? h('span', { class: 's-tag-vrf' }, 'ติดต่อแยก') : null), sub ? h('small', {}, sub) : null),
      vrf ? h('span', { class: 's-price survey' }, 'งานโครงการ') : priceNode(ex, unit),
      h('div', { class: 's-row-w' }, warranty && !vrf ? h('small', {}, warranty) : null),
      vrf ? h('button', { type: 'button', class: 's-add-btn s-ask', onclick: () => askTeam('ระบบ VRV / VRF', name) }, 'ติดต่อสอบถาม')
        : h('button', { type: 'button', class: 's-add-btn', onclick: () => { cart.add(add); toast(`เพิ่ม "${name}" แล้ว`); } }, ex == null ? '+ ขอประเมิน' : '+ เพิ่ม'));
    if (inc || exc) r.append(h('details', { class: 's-row-d' }, h('summary', {}, 'รายละเอียด'), inc ? h('p', {}, h('b', {}, 'รวม: '), inc) : null, exc ? h('p', {}, h('b', {}, 'ไม่รวม: '), exc) : null));
    return r;
  }
  const group = (title, rows, note) => rows.length ? h('section', { class: 's-grp' }, h('h3', {}, title), note ? h('p', { class: 's-note' }, note) : null, h('div', { class: 's-rows' }, rows)) : null;
  function body() {
    out.innerHTML = '';
    if (tab === 'clean') {
      out.append(h('details', { class: 'pk-det', open: true }, h('summary', {}, 'เทียบแพ็กเกจล้าง: ได้อะไร เหมาะกับใคร ราคาเริ่มต้น'), cleanPackageGuide('ศูนย์ราคา', 'h3')));
      const P = CLEAN_PKGS.find(p => p.id === pkg);
      const rows = DATA.clean.filter(r => r.pkg === pkg && r.level === level);
      const first = rows.find(r => r.type);
      out.append(h('div', { class: 's-pc-info' }, h('p', {}, h('b', {}, `${P.th} · ${level === 'C1' ? 'ล้างปกติ' : 'ล้างใหญ่'}`), ` — ${first?.doc || ''}`), h('p', { class: 's-note' }, `รับประกัน ${first?.warranty || '—'} · ${first?.care || ''} · ขั้นต่ำต่อการเข้าหน้างาน ${baht(DATA.minBill)} (${baht(DATA.minBill)} ก่อน VAT)`), first ? h('details', { class: 's-row-d' }, h('summary', {}, 'ขอบเขตงาน'), h('p', {}, h('b', {}, 'รวม: '), first.inc), h('p', {}, h('b', {}, 'ไม่รวม: '), first.exc)) : null));
      TYPES.forEach(t => {
        const rs = rows.filter(r => r.type === t.id && match(r.name, t.th, r.range));
        out.append(group(t.th, rs.map(r => row({ name: `${t.th} ${r.range} BTU`, ex: r.rate.s, unit: r.unit, warranty: r.warranty, add: { kind: 'service', group: 'clean', key: `C-${pkg}-${level}-${t.id}-${r.range}`, name: `${level === 'C1' ? 'ล้างปกติ' : 'ล้างใหญ่'} ${t.th} ${r.range} BTU`, detail: pkg, unitEx: r.rate.s, qty: 1 } }))));
      });
      const extra = rows.filter(r => !r.type && match(r.name, r.ty));
      out.append(group('งานเพิ่ม · AHU · พื้นที่พิเศษ', extra.map(r => row({ name: r.name, sub: `${r.ty} · ${r.range}`, ex: r.rate.s, unit: r.unit, warranty: r.warranty, inc: r.inc, exc: r.exc, add: { kind: r.rate.s == null ? 'survey' : 'service', group: 'clean', key: `CX-${r.name}`, name: r.name, unitEx: r.rate.s, qty: 1 } })), 'รายการที่ไม่มีราคา ทีมประเมินจากหน้างานจริงก่อนเริ่มงาน'));
    }
    if (tab === 'install') {
      const L = { STANDARD: 'มาตรฐาน', PREMIUM: 'พรีเมียม' }[insLevel];
      const items = DATA.inst.filter(i => /^INS-/.test(i.code) && i.code.endsWith('-' + insLevel));
      const sample = items[0];
      out.append(h('div', { class: 's-pc-info' }, h('p', {}, h('b', {}, `ติดตั้ง${L}`), ' — ราคาต่อเครื่อง รวมท่อน้ำยาและวัสดุ 4 เมตรแรก'), sample ? h('details', { class: 's-row-d' }, h('summary', {}, 'ขอบเขตงาน'), h('p', {}, h('b', {}, 'รวม: '), sample.inc), h('p', {}, h('b', {}, 'ไม่รวม: '), sample.exc), h('p', {}, h('b', {}, 'รับประกัน: '), sample.warranty)) : null));
      [['W', 'ติดผนัง'], ['C', 'แขวนใต้ฝ้า'], ['K', 'สี่ทิศทาง'], ['FS', 'ตู้ตั้งพื้น']].forEach(([c, th]) => {
        const rs = items.filter(i => i.code.startsWith(`INS-${c}-`) && match(i.name));
        out.append(group(th, rs.map(i => row({ name: i.name.replace(/^บริการติดตั้ง\S+ — /, ''), ex: i.ex, unit: i.unit, warranty: i.warranty, add: { kind: 'service', group: 'install', key: `I-${i.code}`, name: i.name, unitEx: i.ex, qty: 1 } }))));
      });
      const sv = DATA.inst.filter(i => /^INS-.*SURVEY$/.test(i.code) && match(i.name));
      out.append(group('ระบบอื่น (สำรวจก่อนเสนอราคา)', sv.map(i => row({ name: i.name, ex: null, unit: i.unit, inc: i.inc, exc: i.exc, add: { kind: 'survey', group: 'install', key: `S-${i.code}`, name: i.name, unitEx: null, qty: 1 } }))));
    }
    if (tab === 'repair') {
      const cats = [...new Set(DATA.rep.map(r => r.cat))];
      out.append(h('div', { class: 's-pc-info' }, h('p', {}, h('b', {}, 'ค่าซ่อมตามรายการ'), ' — เริ่มจากค่าตรวจวินิจฉัย ช่างแจ้งราคาซ่อมและรับประกันต่อรายการก่อนลงมือ'), h('p', { class: 's-note' }, 'ราคาที่แสดงเป็นราคามาตรฐาน อะไหล่บางรายการต้องยืนยันรุ่นก่อน')));
      cats.forEach(c => out.append(group(c, DATA.rep.filter(r => r.cat === c && match(r.name, c)).map(r => row({ name: r.name, ex: r.rate.s, unit: r.unit, warranty: r.warranty, inc: r.inc, exc: r.exc, add: { kind: r.rate.s == null ? 'survey' : 'service', group: 'repair', key: `R-${r.name}`, name: r.name, unitEx: r.rate.s, qty: 1 } })))));
    }
    if (tab === 'contract') {
      out.append(h('div', { class: 's-pc-info' }, h('p', {}, h('b', {}, 'สัญญาล้างรายปี (PM)'), ' — ทีมวางรอบล่วงหน้าทั้งปี ส่งรายงานตามแพ็กเกจหลังทุกรอบ วางบิลตามรอบ'), h('p', { class: 's-note' }, `ราคาต่อเครื่องต่อครั้ง อัตรามาตรฐาน · ขั้นต่ำต่อการเข้าหน้างาน ${baht(DATA.minBill)} · อัตราพิเศษตามจำนวนเครื่องยืนยันในใบเสนอราคา`),
        h('button', { type: 'button', class: 's-btn primary', onclick: () => { const b = document.getElementById('b2b'); b && b.scrollIntoView({ behavior: 'smooth' }); } }, 'คำนวณสัญญาของอาคารคุณ')));
      const cardsBox = h('div', { class: 's-pk3' });
      CLEAN_PKGS.forEach(P => {
        const rs = TYPES.map(t => { const a = DATA.clean.find(r => r.pkg === P.id && r.level === 'C1' && r.type === t.id); const b = DATA.clean.find(r => r.pkg === P.id && r.level === 'C2' && r.type === t.id); return a ? [t, a, b] : null; }).filter(Boolean);
        const first = rs[0] && rs[0][1];
        cardsBox.append(h('article', { class: 's-pk' + (P.id === 'Standard Care' ? ' rec' : '') }, h('h3', {}, P.th, P.id === 'Standard Care' ? h('small', {}, 'แนะนำ') : null), h('p', { class: 's-note' }, P.sub),
          h('table', { class: 's-btable' }, h('thead', {}, h('tr', {}, h('th', {}, 'ประเภท (เล็กสุด)'), h('th', {}, 'ล้างปกติ'), h('th', {}, 'ล้างใหญ่'))), h('tbody', {}, rs.filter(([t, a]) => match(t.th, P.th)).map(([t, a, b]) => h('tr', {}, h('td', {}, `${t.th} ${a.range}`), h('td', {}, baht(a.rate.s)), h('td', {}, b ? baht(b.rate.s) : '—'))))),
          first ? h('p', { class: 's-note' }, `เอกสาร: ${first.doc} · รับประกัน ${first.warranty}`) : null));
      });
      out.append(cardsBox);
    }
    if (tab === 'project') {
      out.append(h('div', { class: 's-pc-info' }, h('p', {}, h('b', {}, 'งานโครงการ · รีโนเวท · ระบบใหญ่'), ' — สำรวจหน้างาน ออกแบบ ทำ BOQ แล้วเสนอราคาเป็นงวด'), h('p', { class: 's-note' }, 'งานกลุ่มนี้ราคาขึ้นกับแบบและหน้างานจริง จึงไม่มีราคาตายตัวบนเว็บ กด "ขอประเมิน" เพื่อให้ทีมติดต่อกลับ')));
      out.append(h('div', { class: 's-vrf' }, h('p', {}, h('b', {}, 'VRV / VRF · '), VRF_NOTE), h('button', { type: 'button', class: 's-btn primary', onclick: () => askTeam('ระบบ VRV / VRF') }, 'ติดต่อสอบถาม VRV / VRF')));
      const kinds = [['ระบบ VRF / VRV', 'หลายคอยล์เย็นต่อคอยล์ร้อนชุดเดียว เหมาะกับอาคารสำนักงานและคอนโด'], ['ระบบ Package / Rooftop', 'พื้นที่ใหญ่ โรงงาน โชว์รูม ห้างร้าน'], ['ระบบท่อลม (Duct) และหัวจ่ายลม', 'ซ่อนเครื่องในฝ้า กระจายลมทั่วห้อง'], ['AHU / FCU อาคาร', 'ล้าง ซ่อม ปรับปรุงระบบลมของอาคาร'], ['รีโนเวทเปลี่ยนเครื่องทั้งชั้น', 'รื้อเครื่องเดิม เดินท่อใหม่ ติดตั้ง และจัดการซาก'], ['ห้อง Server / ห้องควบคุม', 'ออกแบบเครื่องสำรอง N+1 และระบบเตือน']];
      out.append(group('ประเภทงาน', kinds.filter(([n, d]) => match(n, d)).map(([n, d]) => row({ name: n, sub: d, ex: null, add: { kind: 'survey', group: 'install', key: `PJ-${n}`, name: `ขอสำรวจ: ${n}`, unitEx: null, qty: 1 } }))));
      const pj = DATA.inst.filter(i => ['05', '15'].some(p => (i.cat || '').startsWith(p)) && match(i.name, i.cat));
      [...new Set(pj.map(i => i.cat))].forEach(c => out.append(group(c.replace(/^\d+\s*/, ''), pj.filter(i => i.cat === c).map(i => row({ name: i.name, ex: i.ex, unit: i.unit, warranty: i.warranty, inc: i.inc, exc: i.exc, add: { kind: i.ex == null ? 'survey' : 'addon', group: 'addon', key: `A-${i.code}`, name: i.name, unitEx: i.ex, qty: 1 } })))));
    }
    const instCats = pre => DATA.inst.filter(i => pre.some(p => (i.cat || '').startsWith(p)));
    if (tab === 'move' || tab === 'mat') {
      const pres = tab === 'move' ? ['13', '11', '14', '16', '12', '17'] : ['06', '07', '08', '09', '10'];
      const all = instCats(pres);
      [...new Set(all.map(i => i.cat))].forEach(c => out.append(group(c.replace(/^\d+\s*/, ''), all.filter(i => i.cat === c && match(i.name, c)).map(i => row({ name: i.name, ex: i.ex, unit: i.unit, warranty: i.warranty, inc: i.inc, exc: i.exc, add: { kind: i.ex == null ? 'survey' : 'addon', group: 'addon', key: `A-${i.code}`, name: i.name, unitEx: i.ex, qty: 1 } })))));
    }
    if (!out.querySelector('.s-row')) out.append(h('p', { class: 's-empty' }, 'ไม่พบรายการที่ค้นหา'));
  }
  head(); body();
  return { show: id => { tab = id; head(); body(); root.scrollIntoView({ behavior: 'smooth' }); } };
}
